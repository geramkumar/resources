import logging
from typing import List
from langchain_core.documents import Document
from langchain_community.document_loaders import (
    TextLoader, DirectoryLoader, PyPDFLoader, CSVLoader,
    JSONLoader, UnstructuredHTMLLoader,
    UnstructuredWordDocumentLoader, UnstructuredExcelLoader,
    SQLDatabaseLoader
)

logger = logging.getLogger(__name__)

def load_text_file(path: str) -> List[Document]:
    logger.info("Loading text file: %s", path)
    return TextLoader(path, encoding="utf-8").load()

def load_directory(path: str, glob: str = "**/*.txt") -> List[Document]:
    logger.info("Loading directory: %s", path)
    return DirectoryLoader(path, glob=glob).load()

def load_pdf(path: str) -> List[Document]:
    logger.info("Loading PDF file: %s", path)
    return PyPDFLoader(path).load()

def load_csv(path: str) -> List[Document]:
    logger.info("Loading CSV file: %s", path)
    return CSVLoader(path).load()

def load_json(path: str, jq_schema: str = ".") -> List[Document]:
    logger.info("Loading JSON file: %s", path)
    return JSONLoader(path, jq_schema=jq_schema).load()

def load_html(path: str) -> List[Document]:
    logger.info("Loading HTML file: %s", path)
    return UnstructuredHTMLLoader(path).load()

def load_word(path: str) -> List[Document]:
    logger.info("Loading Word file: %s", path)
    return UnstructuredWordDocumentLoader(path).load()

def load_excel(path: str) -> List[Document]:
    logger.info("Loading Excel file: %s", path)
    return UnstructuredExcelLoader(path).load()

def load_sqlite(database_uri: str, query: str) -> List[Document]:
    logger.info("Loading SQLite DB: %s", database_uri)
    loader = SQLDatabaseLoader.from_uri(database_uri, query=query)
    return loader.load()

def load_documents(source_type: str, **kwargs) -> List[Document]:
    loaders = {
        "text": load_text_file,
        "directory": load_directory,
        "pdf": load_pdf,
        "csv": load_csv,
        "json": load_json,
        "html": load_html,
        "word": load_word,
        "excel": load_excel,
        "sqlite": load_sqlite,
    }

    if source_type not in loaders:
        raise ValueError(f"Unsupported source type: {source_type}")

    return loaders[source_type](**kwargs)
