import logging
from langchain_community.vectorstores import Chroma, FAISS
from llm import get_embeddings
from config import VECTORSTORE_DIR

logger = logging.getLogger(__name__)

def create_chroma_store(documents):
    logger.info("Creating Chroma vector store")
    return Chroma.from_documents(
        documents=documents,
        embedding=get_embeddings(),
        persist_directory=VECTORSTORE_DIR
    )

def create_faiss_store(documents):
    logger.info("Creating FAISS vector store")
    return FAISS.from_documents(documents, get_embeddings())

def create_vectorstore(store_type: str, documents):
    stores = {
        "chroma": create_chroma_store,
        "faiss": create_faiss_store
    }

    if store_type not in stores:
        raise ValueError(f"Unsupported vector store: {store_type}")

    return stores[store_type](documents)
