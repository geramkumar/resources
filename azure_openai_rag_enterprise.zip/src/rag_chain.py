from langchain.prompts import ChatPromptTemplate
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from llm import get_chat_llm

def build_rag_chain(retriever):
    prompt = ChatPromptTemplate.from_template("""
Answer strictly using the provided context.
If the answer is not present, say "I don't know".

Context:
{context}

Question:
{input}
""")

    document_chain = create_stuff_documents_chain(
        llm=get_chat_llm(),
        prompt=prompt
    )

    return create_retrieval_chain(retriever, document_chain)
