import logging
from logging_config import setup_logging
from ingestion import load_documents
from splitters import recursive_splitter
from vectorstore import create_vectorstore
from rag_chain import build_rag_chain

setup_logging()
logger = logging.getLogger(__name__)

def main():
    docs = load_documents(source_type="text", path="data/raw/data.txt")
    chunks = recursive_splitter().split_documents(docs)

    vectorstore = create_vectorstore("chroma", chunks)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

    rag_chain = build_rag_chain(retriever)
    response = rag_chain.invoke({"input": "What is explained in the document?"})

    print(response["answer"])

if __name__ == "__main__":
    main()
