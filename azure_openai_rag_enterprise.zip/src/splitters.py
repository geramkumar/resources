from langchain.text_splitter import (
    RecursiveCharacterTextSplitter,
    CharacterTextSplitter,
    TokenTextSplitter,
    MarkdownHeaderTextSplitter,
    HTMLHeaderTextSplitter
)

def recursive_splitter():
    return RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)

def character_splitter():
    return CharacterTextSplitter(chunk_size=500, chunk_overlap=50)

def token_splitter():
    return TokenTextSplitter(chunk_size=300, chunk_overlap=50)

def markdown_splitter():
    return MarkdownHeaderTextSplitter(headers_to_split_on=[("#", "H1"), ("##", "H2")])

def html_splitter():
    return HTMLHeaderTextSplitter(headers_to_split_on=[("h1", "H1"), ("h2", "H2")])
