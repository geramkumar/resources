from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from config import CHAT_DEPLOYMENT, EMBEDDING_DEPLOYMENT, AZURE_API_VERSION

def get_embeddings():
    return AzureOpenAIEmbeddings(
        azure_deployment=EMBEDDING_DEPLOYMENT,
        api_version=AZURE_API_VERSION
    )

def get_chat_llm():
    return AzureChatOpenAI(
        azure_deployment=CHAT_DEPLOYMENT,
        api_version=AZURE_API_VERSION,
        temperature=0,
        max_tokens=500
    )
