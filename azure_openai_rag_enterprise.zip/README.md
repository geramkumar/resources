# Enterprise Azure OpenAI RAG (Python)

This repository demonstrates a **production-grade, enterprise-style**
Retrieval-Augmented Generation (RAG) implementation using:

- Azure OpenAI (Chat + Embeddings)
- LangChain
- ChromaDB / FAISS
- uv for dependency management

## Architecture Flow
Data Loader → Text Splitter → Embeddings → Vector DB → Retriever → Prompt → LLM

## Run
```bash
uv sync
python src/main.py
```
