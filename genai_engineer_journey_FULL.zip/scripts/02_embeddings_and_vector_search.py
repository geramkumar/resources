# SCRIPT 02 – EMBEDDINGS & VECTOR SEARCH
# Topics:
# - Text → Vector conversion
# - Cosine similarity
# - Semantic search

from openai import OpenAI
import numpy as np, os

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

docs = [
    "RAG reduces hallucinations",
    "Fine-tuning retrains models",
    "Embeddings convert text to vectors"
]

embeddings = [
    client.embeddings.create(
        model="text-embedding-3-small",
        input=d
    ).data[0].embedding for d in docs
]

query = "How does RAG help?"
q_emb = client.embeddings.create(
    model="text-embedding-3-small",
    input=query
).data[0].embedding

def cos(a,b): return np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b))

scores = [cos(q_emb, e) for e in embeddings]
print(docs[scores.index(max(scores))])

# SAMPLE OUTPUT:
# RAG reduces hallucinations
