# SCRIPT 03 – END-TO-END RAG
# Topics:
# - Retrieval
# - Context injection
# - Grounded generation

from openai import OpenAI
import numpy as np, json, os

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

docs = [
    "RAG uses retrieval",
    "Fine-tuning retrains weights"
]

embs = [
    client.embeddings.create(
        model="text-embedding-3-small",
        input=d
    ).data[0].embedding for d in docs
]

query = "Why use RAG?"
q_emb = client.embeddings.create(
    model="text-embedding-3-small",
    input=query
).data[0].embedding

def cos(a,b): return np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b))

ctx = docs[cos(q_emb, embs[0]) > cos(q_emb, embs[1])]

resp = client.chat.completions.create(
    model="gpt-4.1-mini",
    messages=[
        {"role":"system","content":"Use context only"},
        {"role":"user","content":f"Context:{ctx}\nQ:{query}"}
    ]
)

print(resp.choices[0].message.content)

# SAMPLE OUTPUT:
# RAG is used because...
