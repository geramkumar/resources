# SCRIPT 01 – LLM BASICS RECOLLECTION
# Topics:
# - ChatCompletion API
# - System vs User roles
# - JSON output
# - Response parsing

from openai import OpenAI
import json, os

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

messages = [
    {"role": "system", "content": "Respond ONLY in JSON"},
    {"role": "user", "content": "Explain what RAG is"}
]

response = client.chat.completions.create(
    model="gpt-4.1-mini",
    messages=messages,
    response_format={"type": "json"}
)

print(json.dumps(json.loads(response.choices[0].message.content), indent=2))

# SAMPLE OUTPUT:
# {
#   "definition": "...",
#   "benefits": [...]
# }
