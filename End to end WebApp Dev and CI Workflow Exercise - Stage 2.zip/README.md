# Sample Python Web App with GitLab CI

This project demonstrates:
- Simple Flask web app
- Test using pytest
- CI/CD using GitLab
- Docker image build & push to GitLab Container Registry

See `.gitlab-ci.yml` for CI pipeline details.
